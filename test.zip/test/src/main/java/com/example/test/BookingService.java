package com.example.test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Random;

public class BookingService {
    private static final String BOOK_API_URL = "https://api.site.com/book";
    private static final String APPROVE_API_URL = "https://api.site.com/approve";

    public static boolean bookOrder(String uniqueBarcode, Integer event_id, String event_date, Integer ticket_adult_price, Integer ticket_adult_quantity, Integer ticket_kid_price, Integer ticket_kid_quantity) {
        int retryCount = 0;
        int MAX_RETRIES = 5; // Максимальное количество попыток

        while (retryCount < MAX_RETRIES) {
            try {
                URL url = new URL(BOOK_API_URL);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);

                // Отправка данных для бронирования
                StringBuilder data = new StringBuilder();
                data.append("event_id=").append(event_id).append("&")
                        .append("event_date=").append(event_date).append("&")
                        .append("ticket_adult_price=").append(ticket_adult_price).append("&")
                        .append("ticket_adult_quantity=").append(ticket_adult_quantity).append("&")
                        .append("ticket_kid_price=").append(ticket_kid_price).append("&")
                        .append("ticket_kid_quantity=").append(ticket_kid_quantity);

                byte[] outputBytes = data.toString().getBytes();
                connection.getOutputStream().write(outputBytes);

                // Получение ответа от API бронирования
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line;
                StringBuilder responseBuilder = new StringBuilder();
                while ((line = reader.readLine()) != null) {
                    responseBuilder.append(line).append("\n");
                }
                reader.close();

                String response = responseBuilder.toString();
                ServerResponse serverResponse = parseResponse(response);

                if ("order successfully booked".equals(serverResponse.getMessage())) {
                    System.out.println("Бронирование успешно!");
                    return true;
                } else if ("barcode already exists".equals(serverResponse.getError())) {
                    System.out.println("Попытка бронирования не удалась. Генерация нового кода.");
                    uniqueBarcode = generateUniqueBarcode(8);
                    retryCount++; // Увеличиваем счетчик попыток
                } else {
                    System.err.println("Неожиданный ответ от API бронирования: " + serverResponse);
                    retryCount++;
                }

            } catch (Exception e) {
                System.err.println("Ошибка при отправке запроса на API бронирования: " + e.getMessage());
                retryCount++;
            }
        }

        System.err.println("Максимальное количество попыток достигнуто без успеха.");
        return false;
    }

    public static String generateUniqueBarcode(int length) {
        StringBuilder sb = new StringBuilder(length);
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }

    private static ServerResponse parseResponse(String response) {
        if (response.contains("order successfully booked")) {
            return new ServerResponse("order successfully booked");
        } else if (response.contains("barcode already exists")) {
            return new ServerResponse("barcode already exists");
        } else {
            return new ServerResponse("Неизвестный результат");
        }
    }

    public static boolean approveOrder(String barcode) {
        int retryCount = 0;
        int MAX_RETRIES = 3;

        while (retryCount < MAX_RETRIES) {
            try {
                URL url = new URL(APPROVE_API_URL);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);

                // Отправка данных для подтверждения
                String data = "barcode=" + barcode;
                byte[] outputBytes = data.getBytes();
                connection.getOutputStream().write(outputBytes);

                // Получение ответа от API подтверждения
                int responseCode = connection.getResponseCode();

                if (responseCode == 200) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;
                    StringBuilder responseBuilder = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        responseBuilder.append(line).append("\n");
                    }
                    reader.close();

                    String response = responseBuilder.toString();
                    ServerResponse serverResponse = parseApproveResponse(response);

                    if ("order successfully approved".equals(serverResponse.getMessage())) {
                        System.out.println("Бронирование успешно подтверждено!");
                        return true;
                    } else if (serverResponse.getError() != null) {
                        System.out.println("Попытка подтверждения не удалась. Ошибка: " + serverResponse.getError());
                        retryCount++; // Увеличиваем счетчик попыток
                    }

                } else {
                    System.err.println("Неудачный запрос. Код ответа: " + responseCode);
                    retryCount++;
                }

            } catch (Exception e) {
                System.err.println("Ошибка при отправке запроса на API подтверждения: " + e.getMessage());
                retryCount++;
            }
        }

        System.err.println("Максимальное количество попыток достигнуто без успеха.");
        return false;
    }

    private static ServerResponse parseApproveResponse(String response) {
        if (response.contains("order successfully approved")) {
            return new ServerResponse("order successfully approved");
        } else if (response.contains("event cancelled") || response.contains("no tickets") ||
                response.contains("no seats") || response.contains("fan removed")) {
            return new ServerResponse(response.split(":")[1].trim().replaceAll("\\s+", ""));
        } else {
            return new ServerResponse("Неизвестный результат");
        }
    }
}

package com.example.test;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

public class HelloController {
    @FXML
    private TextField adult_price;

    @FXML
    private TextField adult_quantity;

    @FXML
    private TextField date_e;

    @FXML
    private TextField id_e;

    @FXML
    private TextField kid_price;

    @FXML
    private TextField kid_quantity;
    private static final String API_URL = "https://api.site.com";
    DB db = new DB();

    public static String generateUniqueBarcode(int length) {
        StringBuilder sb = new StringBuilder(length);
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }

//    private static String createUrlEncodedBody(String uniqueBarcode, Integer event_id, String event_date, Integer ticket_adult_price, Integer ticket_adult_quantity, Integer ticket_kid_price, Integer ticket_kid_quantity) throws UnsupportedEncodingException {
//        StringBuilder sb = new StringBuilder();
//        sb.append("uniqueBarcode=").append(URLEncoder.encode(uniqueBarcode, "UTF-8"));
//        sb.append("&event_id=").append(event_id);
//        sb.append("&event_date=").append(URLEncoder.encode(event_date, "UTF-8"));
//        sb.append("&ticket_adult_price=").append(ticket_adult_price);
//        sb.append("&ticket_adult_quantity=").append(ticket_adult_quantity);
//        sb.append("&ticket_kid_price=").append(ticket_kid_price);
//        sb.append("&ticket_kid_quantity=").append(ticket_kid_quantity);
//        return sb.toString();
//    }
//
//
//
//    public static void sendBookingData(String uniqueBarcode, Integer event_id, String event_date, Integer ticket_adult_price, Integer ticket_adult_quantity, Integer ticket_kid_price, Integer ticket_kid_quantity) {
//        try {
//            // Настройка клиента HTTP
//            HttpClient client = HttpClient.newHttpClient();
//
//            // Создание запроса
//            HttpRequest request = HttpRequest.newBuilder()
//                    .uri(URI.create("https://api.site.com/book"))
//                    .header("Content-Type", "application/x-www-form-urlencoded")
//                    .POST(HttpRequest.BodyPublishers.ofString(createUrlEncodedBody(uniqueBarcode, event_id, event_date, ticket_adult_price, ticket_adult_quantity, ticket_kid_price, ticket_kid_quantity)))
//                    .build();
//
//            // Отправка запроса и получение ответа
//            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
//
//            // Обработка ответа
//            int statusCode = response.statusCode();
//            String responseBody = response.body();
//
//            System.out.println("Статус код: " + statusCode);
//            System.out.println("Ответ сервера: " + responseBody);
//
//            // Проверка статуса ответа
//            if (statusCode == 200) {
//                System.out.println("Бронирование успешно!");
//            } else {
//                System.err.println("Ошибка при бронировании. Статус код: " + statusCode);
//                System.err.println("Ответ сервера: " + responseBody);
//            }
//
//        } catch (IOException | InterruptedException e) {
//            System.err.println("Ошибка при отправке запроса: " + e.getMessage());
//        }
//    }

    @FXML
    public void  onClick() throws SQLException, ClassNotFoundException {
        int barcodeLength = 8;
        String uniqueBarcode = generateUniqueBarcode(barcodeLength);
        System.out.println("Уникальный штрих-код: " + uniqueBarcode);
//        ArrayList<String> barcode = db.getBarcode();
//        if (barcode.contains(uniqueBarcode)) {
//            System.out.println("{error: 'barcode already exists'}");
//            uniqueBarcode = generateUniqueBarcode(barcodeLength);
//        } else {
//            System.out.println("{message: 'order successfully booked'}");
//
//        }
        Integer event_id = Integer.valueOf(id_e.getText());
        String event_date = date_e.getText();
        Integer ticket_adult_price = Integer.valueOf(adult_price.getText());
        Integer ticket_adult_quantity = Integer.valueOf(adult_quantity.getText());
        Integer ticket_kid_price = Integer.valueOf(kid_price.getText());
        Integer ticket_kid_quantity = Integer.valueOf(kid_quantity.getText());
        Integer equal_price = (ticket_adult_price*ticket_adult_quantity)+(ticket_kid_price*ticket_kid_quantity);
        BookingService bookingService = new BookingService();

        if (bookingService.bookOrder(uniqueBarcode, event_id, event_date, ticket_adult_price, ticket_adult_quantity, ticket_kid_price, ticket_kid_quantity)) {
            if (bookingService.approveOrder(uniqueBarcode)) {
                System.out.println("Бронирование успешно завершено!");
                db.insertTicet(event_id,event_date,ticket_adult_price,ticket_adult_quantity,ticket_kid_price,ticket_kid_quantity, uniqueBarcode,5, equal_price);
            } else {
                System.err.println("Не удалось подтвердить бронирование.");
            }
        } else {
            System.err.println("Не удалось забронировать место.");
        }


    }


}
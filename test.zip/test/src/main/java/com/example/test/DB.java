package com.example.test;

import java.sql.*;
import java.time.DateTimeException;
import java.util.ArrayList;

public class DB {
    private final String host = "127.0.0.1";
    private final String port = "3306";
    private final String db_name = "nevatrip";
    private final String login = "root";
    private final String pas = "";

    private Connection dbConn = null;

    private Connection getDbConnection() throws ClassNotFoundException, SQLException {
        String connStr = "jdbc:mysql://" + host + ":" + port + "/" + db_name + "?characterEncoding=UTF8";
        Class.forName("com.mysql.cj.jdbc.Driver");
        dbConn = DriverManager.getConnection(connStr, login, pas);
        return dbConn;
    }


    public void insertTicet(Integer event_id, String event_date, Integer ticket_adult_price, Integer ticket_adult_quantity, Integer ticket_kid_price, Integer ticket_kid_quantity, String barcode, Integer user_id, Integer equal_price) throws SQLException, ClassNotFoundException {
        String sql = "INSERT INTO `ticket` (`event_id`, `event_date`, `ticket_adult_price`, `ticket_adult_quantity`, `ticket_kid_price`, `ticket_kid_quantity`, `barcode`, `user_id`, `equal_price`, `created`) VALUES\n" +
                "(?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        PreparedStatement prSt = getDbConnection().prepareStatement(sql);
        prSt.setInt(1,event_id);
        prSt.setString(2,event_date);
        prSt.setInt(3,ticket_adult_price);
        prSt.setInt(4,ticket_adult_quantity);
        prSt.setInt(5,ticket_kid_price);
        prSt.setInt(6,ticket_kid_quantity);
        prSt.setString(7,barcode);
        prSt.setInt(8,user_id);
        prSt.setInt(9,equal_price);
        prSt.executeUpdate();
    }
    public ArrayList<String> getBarcode() throws SQLException, ClassNotFoundException {
        String sql = "SELECT `barcode` FROM ticket";
        PreparedStatement statement = getDbConnection().prepareStatement(sql);
        ResultSet res = statement.executeQuery();
        ArrayList<String> comboBox = new ArrayList<>();
        while (res.next()) {
            comboBox.add(res.getString("barcode"));
        }
        return comboBox;
    }


}

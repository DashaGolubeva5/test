package com.example.test;

public class ServerResponse {
    private String message;
    private String error;

    public ServerResponse(String message) {
        this.message = message;
        this.error = null;
    }


    public String getMessage() {
        return message;
    }

    public String getError() {
        return error;
    }

    @Override
    public String toString() {
        return "ServerResponse{" +
                "message='" + message + '\'' +
                ", error='" + error + '\'' +
                '}';
    }
}
